// Main landing page for Milan Bet 219
export default function Home() { return <h1>Milan Bet 219</h1>; }